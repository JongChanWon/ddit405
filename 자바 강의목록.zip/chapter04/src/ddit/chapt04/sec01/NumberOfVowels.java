package ddit.chapt04.sec01;

import java.util.Scanner;

public class NumberOfVowels {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�ܾ��Է�: ");
		String word = sc.nextLine();
	}
}
