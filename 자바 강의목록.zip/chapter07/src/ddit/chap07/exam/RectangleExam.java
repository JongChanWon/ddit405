package ddit.chap07.exam;

public class RectangleExam {
	public static void main(String[] args) {
		Rectangle rc = new Rectangle(100, 100, 36, 13);
		rc.getVolume();
		Rectangle rc1 = new Rectangle(200, 200, 35, 22);
		rc1.getVolume();
		Rectangle rc2 = new Rectangle(300, 300, 22, 11);
		rc2.getVolume();

	}
}
