package ddit.chap07.sec01;

public class Audio extends Goods {

	Audio(int price) {
		super(price);
	}

	@Override
	public String toString() {
		return "Im Audio";
	}
}
