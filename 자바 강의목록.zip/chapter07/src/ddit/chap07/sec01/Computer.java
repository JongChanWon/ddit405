package ddit.chap07.sec01;

public class Computer extends Goods {

	Computer(int price) {
		super(price);
	}

	public String toString() {
		return "Lenova Computer";
	}
}
