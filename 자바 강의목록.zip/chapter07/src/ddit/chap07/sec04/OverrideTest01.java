package ddit.chap07.sec04;

public class OverrideTest01 {
	public static void main(String[] args) {

		System.out.println(new OverrideTest01().toString());
		Parent parent = new Parent("��");
		System.out.println(parent);

	}
}
