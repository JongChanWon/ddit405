package ddit.chap07.sec08;

public abstract class HttpServlet {
	public abstract void service();

}
