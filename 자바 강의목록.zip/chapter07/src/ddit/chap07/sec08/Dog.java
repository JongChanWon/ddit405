package ddit.chap07.sec08;

public class Dog extends Animal{

	Dog() {
		super("������");
	}

	@Override
	public void sound() {
		System.out.println("�۸�");
	}
}
