package ddit.chap07.sec08;

public class LoginServlet extends HttpServlet {

	@Override
	public void service() {
		System.out.println("�α����� �մϴ�...");

	}
}
