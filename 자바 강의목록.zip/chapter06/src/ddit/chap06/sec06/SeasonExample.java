package ddit.chap06.sec06;

public class SeasonExample {
	public static void main(String[] args) {
		Season season = Season.SPRING;
		System.out.println(season.SPRING.compareTo(season.FALL));
	}
}
