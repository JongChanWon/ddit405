package ddit.chap06.sec06;

public enum Season {
	SPRING, SUMMER, FALL, WINTER
}
