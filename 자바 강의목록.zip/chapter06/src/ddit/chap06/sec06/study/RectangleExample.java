package ddit.chap06.sec06.study;

public class RectangleExample {
	public static void main(String[] args) {
		Rectangle rectangle = new Rectangle(3.82, 8.65);
		System.out.println("����: " + rectangle.getArea());
		System.out.println("�ѷ�: " + rectangle.getCircumference());

	}
}
