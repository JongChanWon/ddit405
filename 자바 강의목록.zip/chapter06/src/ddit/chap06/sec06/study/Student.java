package ddit.chap06.sec06.study;

public class Student {
	private String dept; // �а�
	private int stdNo; // �й�

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

}
