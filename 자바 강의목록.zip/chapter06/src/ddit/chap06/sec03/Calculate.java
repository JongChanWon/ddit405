package ddit.chap06.sec03;

public class Calculate {

	public int add(byte a, byte b) {
		return a + b;
	}

	public int add(short a, short b) {
		return a + b;
	}

	public int add(short a, byte b) {
		return a + b;
	}

	public int add(byte a, short b) {
		return a + b;
	}

	public int add(int a, int b) {
		return a + b;
	}

	public int add(int a, short b) {
		return a + b;
	}

	public int add(short a, int b) {
		return a + b;
	}

}
