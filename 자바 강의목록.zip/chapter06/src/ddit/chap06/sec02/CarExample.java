package ddit.chap06.sec02;

public class CarExample {
	public static void main(String[] args) {
		Car car1 = new Car();
		car1.setCompany("����ڵ���");
		car1.setAuto(true);
		car1.carInfo();

	}
}
