package examanmal02;

public class Animal {
	void eat() {
		
	}
	
	void cry() {
		
	}
	void move() {
		
	}
}
