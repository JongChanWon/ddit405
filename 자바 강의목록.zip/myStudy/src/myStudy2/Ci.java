package myStudy2;

public class Ci {

}

class CiExam {
	public static void main(String[] args) {
		System.out.println("dd");
	}
}