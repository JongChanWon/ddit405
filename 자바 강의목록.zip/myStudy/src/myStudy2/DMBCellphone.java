package myStudy2;

public class DMBCellphone { // �ڽ�

}
