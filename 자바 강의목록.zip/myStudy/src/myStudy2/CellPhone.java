package myStudy2;

public class CellPhone {// �θ�
	void bumo() {
		System.out.println("hi");
	}
}
