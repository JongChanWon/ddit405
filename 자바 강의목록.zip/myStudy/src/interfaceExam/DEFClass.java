package interfaceExam;

public class DEFClass extends ABClass implements GHI{
	public static void main(String[] args) {
		DEFClass def = new DEFClass();
		def.abcClass();
		def.ghi();
	}

	@Override
	public void ghi() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ghi2() {
		// TODO Auto-generated method stub
		
	}
}
