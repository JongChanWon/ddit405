package interfaceExam;

public interface ABC {
	void abc();
	void abc1();
}
