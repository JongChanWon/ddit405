package interfaceExam;

public interface DEF extends ABC{
	void def();
	void def2();
}
