package interfaceExam;

public class ABClass implements DEF{

	@Override
	public void abc() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void abc1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void def() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void def2() {
		// TODO Auto-generated method stub
		
	}
	
	
	public void abcClass() {
		System.out.println("abcClass �޼ҵ�.. �������̵�x");
	}

}
