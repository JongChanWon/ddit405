package interfaceExam;

public interface GHI {
	void ghi();
	void ghi2();
}
