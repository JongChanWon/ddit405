//package exam;
//
//public class SharpPencilExam {
//	public static void main(String[] args) {
//		FountainPen fp = new FountainPen(32, "�Ķ�");
//		fp.refill(21);
//	}
//}
