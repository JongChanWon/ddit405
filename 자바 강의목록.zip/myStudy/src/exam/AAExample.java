package exam;

public class AAExample {
	public static void main(String[] args) {
		BB bb = new BB(11);

	}
}
