package exam;

public class Exam02 {

}
