package myStudy;

public class Study {
	public static void main(String[] args) {
		int[] num = new int[1000];

		for (int i = 0; i < num.length - 1; i++) {
			for (int j = 0; j < num.length - 1 - i; j++) {
				int temp = num[j];

			}
		}
	}
}
