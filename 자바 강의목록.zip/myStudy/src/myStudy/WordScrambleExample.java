package myStudy;

public class WordScrambleExample {
	public static void main(String[] args) {
		WordScramble wordScramble = new WordScramble();
		wordScramble.init();

	}
}
