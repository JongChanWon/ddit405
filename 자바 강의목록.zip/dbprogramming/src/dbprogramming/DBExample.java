package dbprogramming;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DBExample {

	public static Scanner sc = new Scanner(System.in);
	public static Connection conn = null;

	public static void main(String[] args) {
		DBExample db = new DBExample();
		// db.connect();
		db.select();
		db.insert();
//		db.update();
//		db.delete();

	}

	public void connect() {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "pc28";
		String passwd = "java";

		try {
			conn = DriverManager.getConnection(url, user, passwd);
		} catch (Exception e) {
			System.out.println("db ���� ����");
			e.printStackTrace();
		}
		System.out.println("db���� ����!!");
	}

	public void select() {
		// �������ɾ� ��ü: (Statement)
		// �������ɾ� ��ü: ������ �Ҷ� (preparedStatement)
		connect();
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			System.out.println("��ȸ�� ȸ����ȣ �Է�: ");
			String tid = sc.next();
			String sql = "select * from tb1_member where mem_id = ? "; // 1��°
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, tid); // �����Ϳ� tid�� ���� ��Ŵ

//			stmt = conn.createStatement();

//			rs = stmt.executeQuery(sql); // DDL
			rs = pstmt.executeQuery();

//			rs = stmt.executeUpdate(sql); // DML
			// mem_id, mem_name, mem_hp, mem_add1, mem_mileage
			while (rs.next()) { // next() - ��, ���� �Ǵ��ؼ� �����͸� ������
				String mid = rs.getString("mem_id"); // �÷��� �ε����� ������ ���� �ִ�. ex)getString(1) �ٵ� �̷��� �Ⱦ�..
				String name = rs.getString("mem_name");
				String mem_hp = rs.getString("mem_hp");
				String mem_add1 = rs.getString("mem_add1");
				int mileage = rs.getInt("mem_mileage");

				System.out.println(mid + "\t" + name + "\t" + mem_hp + "\t" + mem_add1 + "\t" + mileage);
//				System.out.print(mid + "  "+ name + "  " + mem_hp);
//				System.out.printf("%6d   %10s\n", mileage, mem_add1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public void insert() {
		connect();
		
		System.out.print("�̸�: ");
		String tname = sc.next();
		
		System.out.print("�̸�: ");
		String tnam = sc.next();
		
		
		
		
		
		
		
		
		
	}
}
