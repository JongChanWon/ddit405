package ddit.chap05.sec06;

public class HistogramExample {
	public static void main(String[] args) {
		Histogram histo = new Histogram();
//		histo.calcDice();
		histo.showDiagram();
	}
}
