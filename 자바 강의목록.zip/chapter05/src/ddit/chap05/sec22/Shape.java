package ddit.chap05.sec22;

public class Shape {
	public static void main(String[] args) {
		Triangle triangle = new Triangle();
		triangle.drawShape();
	}
}
