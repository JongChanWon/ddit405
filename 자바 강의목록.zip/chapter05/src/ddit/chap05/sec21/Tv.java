package ddit.chap05.sec21;

public class Tv extends Product {
	Tv() {
		super(1000);
	}

	@Override
	public String toString() {
		return "Television";
	}
}
